<!DOCTYPE html>
<html class="client-nojs" lang="en-GB" dir="ltr">
<head>
<meta charset="UTF-8">
<title>Skins.vector.legacy.js - OSRS Wiki</title>
<script>(function(){var className="client-js";var cookie=document.cookie.match(/(?:^|; )wgmwclientpreferences=([^;]+)/);if(cookie){cookie[1].split('%2C').forEach(function(pref){className=className.replace(new RegExp('(^| )'+pref.replace(/-clientpref-\w+$|[^\w-]+/g,'')+'-clientpref-\\w+( |$)'),'$1'+pref+'$2');});}document.documentElement.className=className;}());RLCONF={"wgBreakFrames":false,"wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgRequestId":"c46fde5b38f89ea57976eeaed2b92978","wgCanonicalNamespace":"","wgCanonicalSpecialPageName":false,"wgNamespaceNumber":0,"wgPageName":"Skins.vector.legacy.js","wgTitle":"Skins.vector.legacy.js","wgCurRevisionId":0,"wgRevisionId":0,"wgArticleId":0,"wgIsArticle":true,"wgIsRedirect":false,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":[],"wgPageViewLanguage":"en-gb","wgPageContentLanguage":"en-gb","wgPageContentModel":"wikitext","wgRelevantPageName":"Skins.vector.legacy.js","wgRelevantArticleId":0,"wgTempUserName":null,"wgIsProbablyEditable":true,"wgRelevantPageIsProbablyEditable":true,"wgRestrictionCreate":[],"simpleBatchUploadMaxFilesPerBatch":{"*":1000},"wgMediaViewerOnClick":true,"wgMediaViewerEnabledByDefault":true,"wgVisualEditor":{"pageLanguageCode":"en-GB","pageLanguageDir":"ltr","pageVariantFallbacks":"en-gb"},"wgMFDisplayWikibaseDescriptions":{"search":false,"watchlist":false,"tagline":false},"wgPopupsFlags":0,"wgEditSubmitButtonLabelPublish":false,"wgCheckUserClientHintsHeadersJsApi":["brands","architecture","bitness","fullVersionList","mobile","model","platform","platformVersion"]};
RLSTATE={"ext.gadget.switch-infobox-styles":"ready","ext.gadget.articlefeedback-styles":"ready","ext.gadget.stickyTableHeaders":"ready","ext.gadget.falseSubpage":"ready","ext.gadget.headerTargetHighlight":"ready","site.styles":"ready","user.styles":"ready","user":"ready","user.options":"loading","skins.vector.styles.legacy":"ready","skins.vector.search.codex.styles":"ready","ext.visualEditor.desktopArticleTarget.noscript":"ready","ext.embedVideo.styles":"ready"};RLPAGEMODULES=["site","mediawiki.page.ready","skins.vector.legacy.js","mmv.bootstrap","ext.gadget.rsw-util","ext.gadget.switch-infobox","ext.gadget.GECharts","ext.gadget.compare","ext.gadget.autosort","ext.gadget.highlightTable","ext.gadget.titleparenthesis","ext.gadget.tooltips","ext.gadget.topIcons","ext.gadget.Username","ext.gadget.countdown","ext.gadget.autocollapse","ext.gadget.checkboxList","ext.gadget.Charts","ext.gadget.navbox-tracking","ext.gadget.sidebar-tracking","ext.gadget.wikisync","ext.gadget.autolistsfull","ext.gadget.articlefeedback","ext.gadget.maps","ext.gadget.calc","ext.gadget.infoboxQty","ext.gadget.dropDisplay","ext.gadget.mmgkc","ext.gadget.fightcaverotations","ext.gadget.livePricesMMG","ext.gadget.skinTogglesNew","ext.gadget.utcclock","ext.gadget.relativetime","ext.gadget.sectionAnchors","ext.gadget.audioplayer","ext.gadget.musicmap","ext.gadget.equipment","ext.gadget.dropdown","ext.gadget.newPage","ext.gadget.purge","ext.gadget.ReferenceTooltips","ext.gadget.oswf","ext.gadget.banktag-converter","ext.gadget.inventorysetups-converter","ext.gadget.searchfocus","ext.gadget.tilemarkers","ext.gadget.loadout","ext.gadget.leaguefilter","ext.gadget.gridMaster","ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader","ext.embedVideo.overlay","ext.checkUser.clientHints","ext.popups"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.impl(function(){return["user.options@12s5i",function($,jQuery,require,module){mw.user.tokens.set({"patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});
}];});});</script>
<link rel="stylesheet" href="/load.php?lang=en-gb&amp;modules=ext.embedVideo.styles%7Cext.visualEditor.desktopArticleTarget.noscript%7Cskins.vector.search.codex.styles%7Cskins.vector.styles.legacy&amp;only=styles&amp;skin=vector&wgcb=2">
<script async="" src="/load.php?lang=en-gb&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector&wgcb=2"></script>
<meta name="ResourceLoaderDynamicStyles" content="">
<link rel="stylesheet" href="/load.php?lang=en-gb&amp;modules=ext.gadget.articlefeedback-styles%2CfalseSubpage%2CheaderTargetHighlight%2CstickyTableHeaders%2Cswitch-infobox-styles&amp;only=styles&amp;skin=vector&wgcb=2">
<link rel="stylesheet" href="/load.php?lang=en-gb&amp;modules=site.styles&amp;only=styles&amp;skin=vector&wgcb=2">
<link rel="preload" href="/images/PT-Serif_Bold.woff2?4af08" as="font" type="font/woff2" crossorigin />
<link rel="preload" href="/images/IBMPlexSans-Regular.woff2?4af08" as="font" type="font/woff2" crossorigin />
<link rel="preload" href="/images/IBMPlexSans-Italic.woff2?4af08" as="font" type="font/woff2" crossorigin />
<link rel="preload" href="/images/IBMPlexSans-Bold.woff2?4af08" as="font" type="font/woff2" crossorigin />
<meta name="generator" content="MediaWiki 1.45.3">
<meta name="robots" content="noindex,nofollow,max-image-preview:standard">
<meta name="format-detection" content="telephone=no">
<meta property="og:title" content="Skins.vector.legacy.js - OSRS Wiki">
<meta property="og:type" content="article">
<meta property="og:site_name" content="Old School RuneScape Wiki">
<meta property="og:url" content="https://oldschool.runescape.wiki/w/Skins.vector.legacy.js">
<meta property="og:image" content="https://oldschool.runescape.wiki/images/Wiki.png">
<meta property="og:image:width" content="135">
<meta property="og:image:height" content="135">
<meta name="viewport" content="width=1120">
<link rel="alternate" type="application/x-wiki" title="Edit" href="/w/Skins.vector.legacy.js?action=edit">
<link rel="apple-touch-icon" href="/images/Apple-touch-icon.png">
<link rel="icon" href="/images/Favicon.ico">
<link rel="search" type="application/opensearchdescription+xml" href="/rest.php/v1/search" title="Old School RuneScape Wiki (en-gb)">
<link rel="EditURI" type="application/rsd+xml" href="https://oldschool.runescape.wiki/api.php?action=rsd">
<link rel="canonical" href="https://oldschool.runescape.wiki/w/Skins.vector.legacy.js">
<link rel="license" href="https://creativecommons.org/licenses/by-nc-sa/3.0/">

            <script>
              window.ramp = window.ramp || {};
              window.ramp.que = window.ramp.que || [];
            </script>
            <script async src="//cdn.intergient.com/1024919/74153/ramp_config.js"></script>
  
            <script>
                // Determine ad placement location (contact Jayden/Cook for issues)
                window.addEventListener('DOMContentLoaded', () => {
                    const body = document.getElementsByClassName('mw-body')[0];
                    if (body) {
                        const sidebar = document.getElementById('mw-panel');
                        const footer = document.getElementsByClassName('mw-footer')[0];
  
                        // Create the elements we will be adding to the page
                        let wrapper = document.createElement('div');
                        wrapper.className = 'adplacement';
                        let placement = document.createElement('div');
                        let adScript = document.createElement('script');
  
                        let reportLink = document.createElement('a');
                        reportLink.href = 'https://discord.gg/axSGh7GJkq'
                        reportLink.style.textAlign = 'center';
                        reportLink.style.display = 'block';
                        reportLink.style.color = '#777777';
                        reportLink.style.textDecoration = 'none';
                        reportLink.style.textTransform = 'uppercase';
                        reportLink.style.fontSize = '9px';
                        reportLink.style.fontFamily = 'Helvetica, Arial, sans-serif';
                        reportLink.style.marginTop = '1em';
                        reportLink.setAttribute('target', '_blank');
                        reportLink.innerText = 'Report Ad';
  
                        if (body.clientHeight > 1700 && sidebar) {
                            // If the page body is over a certain height, and sidebar exists, add a sidebar placement.
                            wrapper.style.paddingBottom = '25px';
                            wrapper.style.marginTop = 'calc(1em + 25px)';
                            // wrapper.style.overflow = 'hidden';
                            // wrapper.style.maxWidth = '160px';
  
                            placement.id = 'wgl-sidebar';
                            placement.id = 'pwDeskSkyBtf1';
                            placement.setAttribute('data-pw-desk', 'sky_btf');
  
                            wrapper.append(placement);
                            wrapper.append(reportLink);
                            sidebar.append(wrapper);
  
                            // Init the placement
                            adScript.textContent = `
                              window.ramp.que.push(function () {
                                  window.ramp.addTag("pwDeskSkyBtf1");
                              })
                            `
                            console.debug('[WGL] Adding sidebar placement');
                            sidebar.append(adScript);
                        } else if (footer) {
                            // Else, add a footer placement.
                            wrapper.style.paddingBottom = '25px';
  
                            placement.id = 'pwDeskLbBtf1';
                            placement.setAttribute('data-pw-desk', 'leaderboard_btf');
  
                            wrapper.append(placement);
                            wrapper.append(reportLink);
                            footer.prepend(wrapper);
  
                            // Init the placement
                            adScript.textContent = `
                              window.ramp.que.push(function () {
                                  window.ramp.addTag("pwDeskLbBtf1");
                              })
                            `
                            console.debug('[WGL] Adding footer placement');
                            footer.append(adScript);
                        }
                    }
                });
            </script>
        </head>
<body class="skin-vector-legacy mediawiki ltr sitedir-ltr mw-hide-empty-elt ns-0 ns-subject mw-editable page-Skins_vector_legacy_js rootpage-Skins_vector_legacy_js skin-vector action-view wgl-lightmode wgl-theme-light"><div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
	<div id="siteNotice"></div>
	<div class="mw-indicators">
	</div>
	<h1 id="firstHeading" class="firstHeading mw-first-heading"><span class="mw-page-title-main">Skins.vector.legacy.js</span></h1>
	<div id="bodyContent" class="vector-body">
		<div id="siteSub" class="noprint">From Old School RuneScape Wiki</div>
		<div id="contentSub"><div id="mw-content-subtitle"></div></div>
		<div id="contentSub2"></div>
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#searchInput">Jump to search</a>
		<div id="mw-content-text" class="mw-body-content"><div class="noarticletext mw-content-ltr" dir="ltr" lang="en-GB">
<div class="tile plainlinks" style="margin: 2em auto; max-width: 32em; min-height: 100px">
<figure class="mw-halign-right" typeof="mw:File"><span><img src="/images/thumb/Weird_gloop_detail.png/75px-Weird_gloop_detail.png?94769" decoding="async" loading="lazy" width="75" height="108" class="mw-file-element" srcset="/images/thumb/Weird_gloop_detail.png/150px-Weird_gloop_detail.png?94769 2x" data-file-width="976" data-file-height="1406" /></span><figcaption></figcaption></figure>
<div class="mw-heading mw-heading2"><h2 id="Nothing_interesting_happens.">Nothing interesting happens.</h2></div>
<p>This page doesn't exist on the wiki. <a href="/w/Special:EditPage/Skins.vector.legacy.js" title="Special:EditPage/Skins.vector.legacy.js">Maybe it should?</a> Alternatively, you can try <a class="text" href="https://oldschool.runescape.wiki/w/Special:Search?search=Skins.vector.legacy.js&amp;fulltext=Search">searching the wiki</a> for Skins.vector.legacy.js.
</p>
</div>
</div>
<div class="printfooter" data-nosnippet="">Retrieved from "<a dir="ltr" href="https://oldschool.runescape.wiki/w/Skins.vector.legacy.js">https://oldschool.runescape.wiki/w/Skins.vector.legacy.js</a>"</div></div>
		<div id="catlinks" class="catlinks catlinks-allhidden" data-mw="interface"></div>
	</div>
</div>

<div id="mw-navigation">
	<h2>Navigation menu</h2>
	<div id="mw-head">
		
<nav id="p-personal" class="mw-portlet mw-portlet-personal vector-user-menu-legacy vector-menu" aria-labelledby="p-personal-label"  >
	<h3
		id="p-personal-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Personal tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list">
			
			<li id="pt-createaccount" class="mw-list-item"><a href="/w/Special:CreateAccount?returnto=Skins.vector.legacy.js" title="You are encouraged to create an account and log in; however, it is not mandatory"><span>Create account</span></a></li><li id="pt-login" class="mw-list-item"><a href="/w/Special:UserLogin?returnto=Skins.vector.legacy.js" title="You are encouraged to log in; however, it is not mandatory [o]" accesskey="o"><span>Log in</span></a></li>
		</ul>
		
	</div>
</nav>

		<div id="left-navigation">
			
<nav id="p-associated-pages" class="mw-portlet mw-portlet-associated-pages vector-menu-tabs vector-menu-tabs-legacy vector-menu" aria-labelledby="p-associated-pages-label"  >
	<h3
		id="p-associated-pages-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">associated-pages</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list">
			
			<li id="ca-nstab-main" class="selected vector-tab-noicon mw-list-item"><a href="/w/Skins.vector.legacy.js?action=edit&amp;redlink=1" title="View the content page (page does not exist) [c]" accesskey="c"><span>Article</span></a></li><li id="ca-talk" class="new vector-tab-noicon mw-list-item"><a href="/w/Talk:Skins.vector.legacy.js?action=edit&amp;redlink=1" rel="discussion" class="new" title="Discussion about the content page (page does not exist) [t]" accesskey="t"><span>Discussion</span></a></li>
		</ul>
		
	</div>
</nav>

			
<nav id="p-variants" class="mw-portlet mw-portlet-variants emptyPortlet vector-menu-dropdown vector-menu" aria-labelledby="p-variants-label"  >
	<input type="checkbox"
		id="p-variants-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-variants"
		class="vector-menu-checkbox"
		aria-labelledby="p-variants-label"
	>
	<label
		id="p-variants-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">British English</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list">
			
			
		</ul>
		
	</div>
</nav>

		</div>
		<div id="right-navigation">
			
<nav id="p-views" class="mw-portlet mw-portlet-views vector-menu-tabs vector-menu-tabs-legacy vector-menu" aria-labelledby="p-views-label"  >
	<h3
		id="p-views-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Views</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list">
			
			<li id="ca-ve-edit" class="mw-list-item"><a href="/w/Skins.vector.legacy.js?veaction=edit" title="Create this page [v]" accesskey="v"><span>Create</span></a></li><li id="ca-edit" class="collapsible mw-list-item"><a href="/w/Skins.vector.legacy.js?action=edit" title="Create the source code of this page [e]" accesskey="e"><span>Create source</span></a></li>
		</ul>
		
	</div>
</nav>

			
<nav id="p-cactions" class="mw-portlet mw-portlet-cactions emptyPortlet vector-menu-dropdown vector-menu" aria-labelledby="p-cactions-label"  title="More options" >
	<input type="checkbox"
		id="p-cactions-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-cactions"
		class="vector-menu-checkbox"
		aria-labelledby="p-cactions-label"
	>
	<label
		id="p-cactions-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">More</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list">
			
			
		</ul>
		
	</div>
</nav>

			
<div id="p-search" role="search" class="vector-search-box-vue  vector-search-box-show-thumbnail vector-search-box-auto-expand-width vector-search-box">
	<div class="vector-typeahead-search-container">
		<div class="cdx-typeahead-search cdx-typeahead-search--show-thumbnail cdx-typeahead-search--auto-expand-width">
			<form action="/" id="searchform" class="cdx-search-input cdx-search-input--has-end-button">
				<div id="simpleSearch" class="cdx-search-input__input-wrapper"  data-search-loc="header-navigation">
					<div class="cdx-text-input cdx-text-input--has-start-icon">
						<input
							class="cdx-text-input__input mw-searchInput" autocomplete="off"
							 type="search" name="search" placeholder="Search the OSRS Wiki" aria-label="Search the OSRS Wiki" autocapitalize="sentences" spellcheck="false" title="Search the wiki [f]" accesskey="f" id="searchInput"
							>
						<span class="cdx-text-input__icon cdx-text-input__start-icon"></span>
					</div>
					<input type="hidden" name="title" value="Special:Search">
				</div>
				<button class="cdx-button cdx-search-input__end-button">Search</button>
			</form>
		</div>
	</div>
</div>

		</div>
	</div>
	
<div id="mw-panel" class="vector-legacy-sidebar">
	<div id="p-logo" role="banner">
		<a class="mw-wiki-logo" href="/"
			title="Visit the main page"></a>
	</div>
	
<nav id="p-Discord" class="mw-portlet mw-portlet-Discord vector-menu-portal portal vector-menu" aria-labelledby="p-Discord-label"  >
	<h3
		id="p-Discord-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Discord</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list">
			
			<li id="n-Discord" class="mw-list-item"><a rel="nofollow" target="_blank" href="https://discord.gg/96a5V2EGh2"><span>Discord</span></a></li>
		</ul>
		
	</div>
</nav>

	
<nav id="p-Navigation" class="mw-portlet mw-portlet-Navigation vector-menu-portal portal vector-menu" aria-labelledby="p-Navigation-label"  >
	<h3
		id="p-Navigation-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Navigation</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list">
			
			<li id="n-mainpage-description" class="mw-list-item"><a href="/" title="Visit the main page [z]" accesskey="z"><span>Main page</span></a></li><li id="n-About-us" class="mw-list-item"><a href="/w/RuneScape:About"><span>About us</span></a></li><li id="n-randompage" class="mw-list-item"><a href="/w/Special:RandomRootpage/main" title="Load a random page [x]" accesskey="x"><span>Random page</span></a></li><li id="n-contactpage" class="mw-list-item"><a href="/w/RuneScape:Contact_us"><span>Contact us</span></a></li><li id="n-Donate" class="mw-list-item"><a rel="nofollow" target="_blank" href="https://patreon.com/runescapewiki"><span>Donate</span></a></li>
		</ul>
		
	</div>
</nav>

<nav id="p-Recent_changes" class="mw-portlet mw-portlet-Recent_changes vector-menu-portal portal vector-menu" aria-labelledby="p-Recent_changes-label">
	<h3
		id="p-Recent_changes-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Recent changes</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list">
			
			
		
<li class="mw-list-item rc-sidebar-item">
  <a class="rc-sidebar-page" href="/w/Dart">Dart</a>
  <p class="rc-sidebar-user">
    <a href="/?diff=15402240">14m <span class="rc-sidebar-ago">ago</span></a>&nbsp;-
    <a href="/w/Special:Contributions/Mr_Zozo">Mr Zozo</a>
  </p>
</li>
<li class="mw-list-item rc-sidebar-item">
  <a class="rc-sidebar-page" href="/w/Theatre_of_Blood%2FStrategies">Theatre of Blood/Strategies</a>
  <p class="rc-sidebar-user">
    <a href="/?diff=15402239">14m <span class="rc-sidebar-ago">ago</span></a>&nbsp;-
    <a href="/w/Special:Contributions/Bootington">Bootington</a>
  </p>
</li>
<li class="mw-list-item rc-sidebar-item">
  <a class="rc-sidebar-page" href="/w/Arrows">Arrows</a>
  <p class="rc-sidebar-user">
    <a href="/?diff=15402238">18m <span class="rc-sidebar-ago">ago</span></a>&nbsp;-
    <a href="/w/Special:Contributions/Mr_Zozo">Mr Zozo</a>
  </p>
</li>
<li class="mw-list-item rc-sidebar-item">
  <a class="rc-sidebar-page" href="/w/Bone_spear">Bone spear</a>
  <p class="rc-sidebar-user">
    <a href="/?diff=15402237">19m <span class="rc-sidebar-ago">ago</span></a>&nbsp;-
    <a href="/w/Special:Contributions/SabSparrow">SabSparrow</a>
  </p>
</li>
<li class="mw-list-item rc-sidebar-item rc-sidebar-more">
    <a class="rc-sidebar-page" href="/w/Special:RecentChanges" accesskey="r">Show more...</a>
</li></ul>
		
	</div>
</nav>

<nav id="p-Guides" class="mw-portlet mw-portlet-Guides vector-menu-portal portal vector-menu" aria-labelledby="p-Guides-label"  >
	<h3
		id="p-Guides-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Guides</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list">
			
			<li id="n-Recent-updates" class="mw-list-item"><a href="/w/2026"><span>Recent updates</span></a></li><li id="n-List-of-quests" class="mw-list-item"><a href="/w/Quests/List"><span>List of quests</span></a></li><li id="n-Achievement-diaries" class="mw-list-item"><a href="/w/Achievement_Diary"><span>Achievement diaries</span></a></li><li id="n-Combat-achievements" class="mw-list-item"><a href="/w/Combat_Achievements"><span>Combat achievements</span></a></li><li id="n-Skill-training" class="mw-list-item"><a href="/w/Skill_training_guides"><span>Skill training</span></a></li><li id="n-Money-making" class="mw-list-item"><a href="/w/Money_making_guide"><span>Money making</span></a></li><li id="n-Calculators" class="mw-list-item"><a href="/w/Calculators"><span>Calculators</span></a></li><li id="n-DPS-calculator" class="mw-list-item"><a target="_blank" href="https://tools.runescape.wiki/osrs-dps/"><span>DPS calculator</span></a></li><li id="n-New-player-guide" class="mw-list-item"><a href="/w/New_player_guide"><span>New player guide</span></a></li>
		</ul>
		
	</div>
</nav>

<nav id="p-Community" class="mw-portlet mw-portlet-Community vector-menu-portal portal vector-menu" aria-labelledby="p-Community-label"  >
	<h3
		id="p-Community-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Community</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list">
			
			<li id="n-User-help" class="mw-list-item"><a href="/w/RuneScape:User_help"><span>User help</span></a></li><li id="n-Active-discussions" class="mw-list-item"><a href="/w/RuneScape:Active_discussions"><span>Active discussions</span></a></li><li id="n-Policies" class="mw-list-item"><a href="/w/RuneScape:Policies"><span>Policies</span></a></li>
		</ul>
		
	</div>
</nav>

<nav id="p-More_RuneScape" class="mw-portlet mw-portlet-More_RuneScape vector-menu-portal portal vector-menu" aria-labelledby="p-More_RuneScape-label"  >
	<h3
		id="p-More_RuneScape-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">More RuneScape</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list">
			
			<li id="n-RuneScape-Wiki" class="mw-list-item"><a href="//runescape.wiki/w/RuneScape_Wiki"><span>RuneScape Wiki</span></a></li><li id="n-RSC-Wiki" class="mw-list-item"><a href="//classic.runescape.wiki/w/RuneScape_Classic_Wiki"><span>RSC Wiki</span></a></li><li id="n-Dragonwilds-Wiki" class="mw-list-item"><a href="https://dragonwilds.runescape.wiki/w/Main_Page"><span>Dragonwilds Wiki</span></a></li>
		</ul>
		
	</div>
</nav>

<nav id="p-tb" class="mw-portlet mw-portlet-tb vector-menu-portal portal vector-menu" aria-labelledby="p-tb-label"  >
	<h3
		id="p-tb-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list">
			
			<li id="t-whatlinkshere" class="mw-list-item"><a href="/w/Special:WhatLinksHere/Skins.vector.legacy.js" title="A list of all wiki pages that link here [j]" accesskey="j"><span>What links here</span></a></li><li id="t-print" class="mw-list-item"><a href="javascript:print();" rel="alternate" title="Printable version of this page [p]" accesskey="p"><span>Printable version</span></a></li><li id="t-info" class="mw-list-item"><a href="/w/Skins.vector.legacy.js?action=info" title="More information about this page"><span>Page information</span></a></li><li id="n-specialpages" class="mw-list-item"><a href="/w/Special:SpecialPages"><span>Special pages</span></a></li><li class="mw-list-item"><a href="/w/Special:NewFiles"><span>New files</span></a></li><li id="n-bucket" class="mw-list-item"><a href="/w/Skins.vector.legacy.js?action=bucket" title="Bucket"><span>View buckets</span></a></li>
		</ul>
		<div class="after-portlet after-portlet-tb">            <a href="/hp/1794609540" style="display: none;"></a></div>
	</div>
</nav>

	
</div>

</div>

<footer id="footer" class="mw-footer" >
	<ul id="footer-info">
</ul>

	<ul id="footer-places">
	<li id="footer-places-privacy"><a href="//weirdgloop.org/privacy">Privacy policy</a></li>
	<li id="footer-places-about"><a href="/w/RuneScape:About">About the Old School RuneScape Wiki</a></li>
	<li id="footer-places-disclaimers"><a href="/w/RuneScape:General_disclaimer">Disclaimers</a></li>
	<li id="footer-places-tou"><a href="//weirdgloop.org/terms">Terms of Use</a></li>
	<li id="footer-places-contact"><a href="/w/Special:Contact">Contact Weird Gloop</a></li>
	<li id="footer-places-mobileview"><a href="https://oldschool.runescape.wiki/w/Skins.vector.legacy.js?mobileaction=toggle_view_mobile" class="noprint stopMobileRedirectToggle">Mobile view</a></li>
</ul>

	<ul id="footer-icons" class="noprint">
	<li id="footer-copyrightico"><a href="https://creativecommons.org/licenses/by-nc-sa/3.0/" target="_blank"><img src="https://meta.weirdgloop.org/images/Creative_Commons_footer.png" srcset="https://meta.weirdgloop.org/images/Creative_Commons_footer@2x.png 2x" alt="CC BY-NC-SA 3.0" width="88" height="31" loading="lazy"></a></li>
	<li id="footer-poweredbyico"><a href="https://weirdgloop.org" target="_blank"><img src="https://meta.weirdgloop.org/images/Weird_Gloop_footer.png" srcset="https://meta.weirdgloop.org/images/Weird_Gloop_footer@2x.png 2x" alt="A Weird Gloop wiki" width="88" height="31" loading="lazy"></a></li>
</ul>

</footer>

<div class="mw-portlet mw-portlet-dock-bottom emptyPortlet vector-menu-portal portal" id="p-dock-bottom">
	<ul>
		
	</ul>
</div>
<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgHostname":"mediawiki-7ccc959988-ss5kb","wgBackendResponseTime":36,"wgPageParseReport":{"limitreport":{"cputime":"0.004","walltime":"0.004","ppvisitednodes":{"value":18,"limit":1000000},"revisionsize":{"value":94,"limit":8388608},"postexpandincludesize":{"value":1146,"limit":8388608},"templateargumentsize":{"value":0,"limit":8388608},"expansiondepth":{"value":6,"limit":100},"expensivefunctioncount":{"value":0,"limit":500},"unstrip-depth":{"value":0,"limit":20},"unstrip-size":{"value":0,"limit":5000000},"timingprofile":["100.00%    0.987      1 Template:Noarticletext","100.00%    0.987      1 -total"]},"bucket":{"limitreport-run-time":{"value":"0.000","limit":"10"}},"cachereport":{"origin":"mediawiki-7ccc959988-ss5kb","timestamp":"20261113223900","ttl":172800,"transientcontent":false}}});});</script>

            <script async src="//cdn.intergient.com/ramp_core.js"></script>
        
<script>
( () => {
    const initTime = performance.now();
    const reportFn = p => ( fetch( "https://weirdgloop.org/ai-scrapers-suck", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify( {
            ray: "a5a1451c681a31f9",
            time: performance.now() - initTime,
            ...p,
        } ),
    } ) );
    let cancelFurther = false;
    const callback = e => {
        removeEventListener( e.type, callback );

        if ( cancelFurther ) {
            return;
        }
        cancelFurther = true;

        let data = {};
        if ( event.type.indexOf( 'pointer' ) === 0 ) {
            data = {
                pointerType: e.pointerType,
                x: e.clientX,
                y: e.clientY,
                sx: e.screenX,
                sy: e.screenY,
                dx: e.movementX,
                dy: e.movementY,
            };
        }

        reportFn( {
            type: e.type,
            isTrusted: e.isTrusted,
            area: !( e.target && e.target.closest ) ? null :
                !!e.target.closest( '#p-search' ) ? 'search' :
                !!e.target.closest( '#content' ) ? 'content' :
                !!e.target.closest( '#mw-panel' ) ? 'panel' :
                !!e.target.closest( '#mw-head' ) ? 'head' :
                !!e.target.closest( '#footer' ) ? 'footer' :
                ( e.target.closest( '[id]' )?.id ?? e.target.tagName ),
            ...data,
        } );
    };
    for ( const event of ["pointermove","pointerdown","pointerup","keydown"] ) {
        addEventListener( event, callback, { passive: true } );
    }
    
} )();
</script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092" integrity="sha512-UKNk8GbxkABxKcXYuLkO16EleLGUkcvJWtpSNmExE0Too3ZaFAxTscNWEc1OdAv5/BikHawapSCaiD2XCmp+Bw==" data-cf-beacon='{"version":"2024.11.0","token":"6348a5ceb9674fe390473560fffff798","spa":2}' crossorigin="anonymous"></script>
</body>
</html>